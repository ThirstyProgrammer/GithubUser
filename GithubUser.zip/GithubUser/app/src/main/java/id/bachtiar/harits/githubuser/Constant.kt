package id.bachtiar.harits.githubuser

class Constant {

    object Extras {
        const val USER_DATA = "user_data"
    }
}