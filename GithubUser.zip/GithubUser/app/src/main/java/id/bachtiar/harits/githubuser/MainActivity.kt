package id.bachtiar.harits.githubuser

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import id.bachtiar.harits.githubuser.databinding.ActivityMainBinding
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val stack: Stack<Fragment> = Stack()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupActionBar()
        initListFragment()
    }

    private fun initListFragment() {
        val mFragmentManager = supportFragmentManager
        val mListFragment = ListFragment()
        val fragment = mFragmentManager.findFragmentByTag(ListFragment::class.java.simpleName)

        if (fragment !is ListFragment) {
            mFragmentManager.beginTransaction()
                .add(R.id.frame_container, mListFragment, ListFragment::class.java.simpleName)
                .commit()
        }
    }

    private fun setupActionBar() {
        setSupportActionBar(binding.toolbar)
        setActionBarState()
        supportFragmentManager.addOnBackStackChangedListener {
            setActionBarState()
        }
    }

    private fun setActionBarState() {
        if (supportFragmentManager.backStackEntryCount > 0) {
            if (supportActionBar != null) {
                supportActionBar!!.setDisplayHomeAsUpEnabled(true)
                supportActionBar!!.setDisplayShowHomeEnabled(true)
                binding.toolbar.setNavigationOnClickListener {
                    popFragment()
                }
            }
        } else {
            if (supportActionBar != null) {
                supportActionBar!!.title = getString(R.string.app_name)
                supportActionBar!!.setDisplayHomeAsUpEnabled(false)
            }
        }
    }

    private fun popFragment() {
        if (!stack.isEmpty()) {
            stack.pop()
            initListFragment()
        } else super.onBackPressed()
    }
}