package id.bachtiar.harits.githubuser

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import id.bachtiar.harits.githubuser.databinding.ItemUserBinding

class UserAdapter(private val list: ArrayList<User>) :
    RecyclerView.Adapter<UserAdapter.UserViewHolder>() {

    private lateinit var listener: OnItemClickCallback

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserAdapter.UserViewHolder {
        val binding: ItemUserBinding =
            ItemUserBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        return UserViewHolder(binding)
    }

    override fun onBindViewHolder(holder: UserAdapter.UserViewHolder, position: Int) {
        holder.bind(list[position])
        holder.itemView.setOnClickListener {
            listener.onItemClicked(list[position])
        }
    }

    override fun getItemCount(): Int = list.size

    fun setOnItemClickCallback(onItemClicCallback: OnItemClickCallback) {
        this.listener = onItemClicCallback
    }

    inner class UserViewHolder constructor(private val binding: ItemUserBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(user: User) {
            with(binding) {
                val context = root.context
                val resource =
                    context.resources.getIdentifier(user.avatar, "drawable", context.packageName)
                Glide.with(context)
                    .load(resource)
                    .into(imgItemPhoto)
                tvUsername.text = user.username
                tvName.text = user.name
            }
        }
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: User)
    }
}